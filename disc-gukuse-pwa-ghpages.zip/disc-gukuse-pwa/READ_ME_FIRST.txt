1) start_windows.cmd もしくは start_mac.command を実行
2) ブラウザで http://localhost:8080/ を開く
3) タブ：結果 / 処方箋 / 練習
