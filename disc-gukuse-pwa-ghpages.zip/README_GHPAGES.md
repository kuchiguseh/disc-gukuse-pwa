# GitHub Pages デプロイ手順

1. GitHubで新規リポジトリを作成（例: disc-gukuse-pwa）
2. このZIPを解凍して、中身をそのままリポジトリの直下へアップロード
3. GitHub > Settings > Pages:
   - Source: Deploy from a branch
   - Branch: main / root を選択して Save
4. 数十秒後、表示された URL を開く（例: https://<yourname>.github.io/disc-gukuse-pwa/）

※更新が反映されない場合は、service-worker.js の CACHE_NAME を上げて再デプロイしてください（本ZIPは v2）。
